// ---------------------------------------------------------------------------
// All editable site copy lives here. Swap names, numbers, and links without
// touching component code.
// ---------------------------------------------------------------------------

export const brand = {
  name: "Alex Rivera",
  role: "Full-Stack Developer",
  tagline: "Websites for restaurants, salons & local businesses",
  email: "hello@alexrivera.dev",
  github: "https://github.com/yourusername",
  linkedin: "https://linkedin.com/in/yourusername",
  twitter: "https://x.com/yourusername",
  available: true,
};

export const nav = [
  { label: "Services", href: "#services" },
  { label: "Work", href: "#portfolio" },
  { label: "Process", href: "#process" },
  { label: "FAQ", href: "#faq" },
];

export const hero = {
  eyebrow: "Open for new projects",
  headline: ["Turn Your Business Into a", "24/7 Sales Machine"],
  sub: "Your customers are looking for you right now — on Google at midnight, on Instagram between meetings, at a red light deciding where to eat. A website built to convert turns that moment into a booking, an order, or a call. Even while you sleep.",
  primaryCta: { label: "Get Free Consultation", href: "#contact" },
  secondaryCta: { label: "View My Work", href: "#portfolio" },
  stats: [
    { value: "30+", label: "sites shipped" },
    { value: "2 wks", label: "avg. turnaround" },
    { value: "100%", label: "mobile-ready" },
  ],
};

export const services = [
  {
    icon: "Zap",
    title: "Landing Pages",
    description:
      "A single, focused page built to do one job — turn visitors into leads. Built for promotions, new openings, or testing a new offer fast.",
    benefits: [
      "Live in days, not weeks",
      "One clear call to action",
      "Built to load fast on mobile",
    ],
  },
  {
    icon: "Store",
    title: "Business Websites",
    description:
      "A complete digital home for your business — menu, services, gallery, hours, and location, all in one site your customers trust.",
    benefits: [
      "Multiple pages, fully structured",
      "You can update it yourself",
      "Maps, hours & booking built in",
    ],
  },
  {
    icon: "LayoutGrid",
    title: "Custom Web Applications",
    description:
      "Beyond a website: booking systems, internal tools, and customer portals built around how your business actually runs day to day.",
    benefits: [
      "Tailored to your workflow",
      "Grows with your business",
      "Secure logins & databases",
    ],
  },
];

export const whyChooseMe = [
  {
    icon: "Rocket",
    title: "Fast Delivery",
    description: "Most projects launch in 1–3 weeks, not months. You'll always know what's next.",
  },
  {
    icon: "Sparkles",
    title: "Modern Design",
    description: "Clean, current layouts that make a small business look like a serious one.",
  },
  {
    icon: "Search",
    title: "SEO Friendly",
    description: "Built so Google can actually find you — structured pages, fast load times, real metadata.",
  },
  {
    icon: "Smartphone",
    title: "Mobile Responsive",
    description: "Most of your customers will land on a phone. Your site is designed there first.",
  },
  {
    icon: "ShieldCheck",
    title: "Secure & Scalable",
    description: "Modern hosting, HTTPS by default, and code that won't fall over as you grow.",
  },
];

export const portfolio = [
  {
    title: "Casa Bella",
    category: "Restaurant Landing Page",
    description: "A single-page site for a family-owned Italian restaurant, built around reservations and the evening menu.",
    tech: ["React", "Tailwind", "Framer Motion"],
    gradient: "from-amber-500/30 via-orange-500/10 to-transparent",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Wanderlust Travel Co.",
    category: "Booking Platform",
    description: "A full travel agency site with package browsing, itinerary requests, and a custom quote-builder form.",
    tech: ["Next.js", "Node.js", "PostgreSQL"],
    gradient: "from-cyan-500/30 via-sky-500/10 to-transparent",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Glow Beauty Studio",
    category: "Salon Booking App",
    description: "Online appointment booking with live stylist availability, service pricing, and automated reminders.",
    tech: ["React", "Express", "Stripe"],
    gradient: "from-rose-500/30 via-pink-500/10 to-transparent",
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Ironclad Fitness",
    category: "Business Website",
    description: "A membership-focused gym site with class schedules, trainer profiles, and a lead-capture trial offer.",
    tech: ["React", "Tailwind", "Sanity CMS"],
    gradient: "from-emerald-500/30 via-teal-500/10 to-transparent",
    demoUrl: "#",
    githubUrl: "#",
  },
];

export const process = [
  {
    number: "01",
    title: "Discovery",
    duration: "1–2 days",
    description: "We talk about your business, your customers, and what's actually stopping people from booking or buying today.",
  },
  {
    number: "02",
    title: "Design",
    duration: "3–4 days",
    description: "You see a real design of your homepage before a line of code is written — so there are no surprises later.",
  },
  {
    number: "03",
    title: "Development",
    duration: "5–10 days",
    description: "I build the site to be fast, responsive, and easy for you to maintain, with progress check-ins along the way.",
  },
  {
    number: "04",
    title: "Launch",
    duration: "1 day",
    description: "Your site goes live on your domain, connected to analytics and search console, ready for real customers.",
  },
];

export const testimonials = [
  {
    name: "Maria Santos",
    role: "Owner, Casa Bella Restaurant",
    quote:
      "Online reservations doubled in the first month. Customers keep telling us they found us through the new site.",
  },
  {
    name: "James Okafor",
    role: "Founder, Wanderlust Travel Co.",
    quote:
      "Alex actually understood our business before designing anything. The quote-request form alone has paid for the whole project.",
  },
  {
    name: "Elena Petrova",
    role: "Owner, Glow Beauty Studio",
    quote:
      "Booking used to happen over text messages all day. Now it happens on the site, automatically, even at night.",
  },
];

export const faq = [
  {
    question: "How long does a project actually take?",
    answer:
      "A landing page usually takes 3–7 days. A full business website takes 1–3 weeks depending on the number of pages and features. Custom web applications vary based on scope — we'll agree on a timeline before any work starts.",
  },
  {
    question: "How much does a website cost?",
    answer:
      "It depends on what you need — a landing page, a full business site, or a custom application. Book a free consultation and you'll get a clear, fixed quote before committing to anything.",
  },
  {
    question: "Do you offer support after the site launches?",
    answer:
      "Yes. Every project includes a support window after launch for fixes and small adjustments, and I offer ongoing maintenance plans for businesses that want regular updates.",
  },
  {
    question: "I don't have a logo or branding yet — is that a problem?",
    answer:
      "Not at all. Many clients start from scratch. We'll define a simple, consistent look for your business as part of the design phase.",
  },
  {
    question: "What do you need from me to get started?",
    answer:
      "Just your business details, a few photos if you have them, and answers to a short discovery questionnaire. I handle the rest — copywriting included if you need it.",
  },
  {
    question: "Do you work with businesses outside my country?",
    answer:
      "Yes, all communication and delivery happens remotely over video calls, email, and shared documents, so location isn't a barrier.",
  },
];

export const projectTypes = [
  "Landing Page",
  "Business Website",
  "Web Application",
  "Not sure yet",
];
